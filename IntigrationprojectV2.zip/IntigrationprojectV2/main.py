# Create a test that determines weather you are an introvert or an extrovert
# Then create a test that determines which college at FGCU you should go into
# Then list the major options in the college the user picks.

# Random Things
for x in range(1, 2):
    print(x)

number_1 = 10
number_2 = 20
addition = number_1 + number_2
subtraction = addition - 1
multiplication = subtraction * 5
division = multiplication / 2
exponentiation = division ** 3
modulus = exponentiation % 4
floor_division = modulus // 2
print("Version", floor_division)


# Result Function
def introvert_extrovert_result(intro, extro):
    if intro > extro:
        print("You are an introvert")
    elif intro < extro:
        print("You are an extrovert")
    else:
        print("You are an ambivert")


# Ryan Taulien
# Personality test

# Greeting
print("Greeting User ", end="")
print("My name is Ryan," * 1)
print("I will be your guide today!")
input()
print("This is an Introvert and Extrovert Test")
input()
print("I was born 08", "06", "2003", sep="-", )
input()
age = int(input("How old are you? "))
if age == 19:
    print("WOW! We are the same age")
elif age > 19:
    print("You are old, LOL :)")
else:
    print("You are so young!")
input()

# user introduction
name = input("What is your name? ")
print("Hello, " + name + "!")
input()
print("I am going to ask you questions and reply with 'yes' or 'no'")
input()

answer = input("Type 'yes' to continue: ")
while answer.lower() != "yes":
    answer = input("Invaild input. Please type 'yes' to continue: ")
print("Awsome! Let's begin")

# Introvert & Extrovert Questions
print("Please answer the questions with 'yes' or no")

introvert_counter = 0
extrovert_counter = 0

# Questions
response = input("Do you hang out with friends more that 4 times a week? ")
if response.lower() == "yes":
    extrovert_counter += 1
else:
    introvert_counter += 1

response = input("Does being around people for long periods of time drain you? ")
if response.lower() == "yes":
    introvert_counter += 1
else:
    extrovert_counter += 1

response = input("Do you like working alone? ")
if response.lower() == "yes":
    introvert_counter += 1
else:
    extrovert_counter += 1

response = input("Do you call a friend when you need help? ")
if response.lower() == "yes":
    extrovert_counter += 1
else:
    introvert_counter += 1

response = input("Do you think you have more fun when you do things with friends? ")
if response.lower() == "yes":
    extrovert_counter += 1
else:
    introvert_counter += 1

response = input("Do you think a zoom meeting is better than an in person meeting ")
if response.lower() == "yes":
    introvert_counter += 1
else:
    extrovert_counter += 1

print("Congrats, " + name + " you are done with test 1 ")
input()
introvert_extrovert_result(introvert_counter, extrovert_counter)

# More Random Things
feedback = int(input("On a scale of 1-10 how much did you like this test? (1 = hated it , 10 = loved it "))
if feedback == 1 or feedback == 2 or feedback == 3:
    print("Sorry :(")
elif feedback >= 4 and feedback <= 10:
    print("YAY :)")
else:
    print("Please type a number between 1-10. ")

# Requirement
happy = input("Do you believe the test was accurate ")
if not happy == "yes":
    print("Sorry, but the test is right!")
else:
    print("Awsome!")
